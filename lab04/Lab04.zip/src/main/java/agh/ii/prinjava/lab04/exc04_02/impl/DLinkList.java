package agh.ii.prinjava.lab04.exc04_02.impl;

public class DLinkList<E> {
    // ...
    private static class Node<T> {
        T elem;
        Node<T> next;
        Node<T> prev;
    }
}
